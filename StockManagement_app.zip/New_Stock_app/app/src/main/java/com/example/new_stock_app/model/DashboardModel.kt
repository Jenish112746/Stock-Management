package com.example.new_stock_app.model

data class DashboardModel(

    val category_id: Int = 0,
    val id: Int = 0,
    val stockName: String? = null,
    val stockNumber: String? = null,
    val stockTotalPrice: String? = null,
    val stockCurrentPrice: String? = null,
    val stockYourPrice: String? = null,
    val manage: String? = null,
    val description: String? = null,
)
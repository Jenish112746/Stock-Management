package com.example.new_stock_app.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.new_stock_app.R
import com.example.new_stock_app.activity.DashboardUpdate
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.google.android.material.textview.MaterialTextView

class HistoryAdapter(var historyModels: ArrayList<DashboardModel>, var context: Context) : RecyclerView.Adapter<HistoryAdapter.DashboardViewHolder>() {

    private var rs: String? = null
    private var databaseHelper: DatabaseHelper? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): HistoryAdapter.DashboardViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_history, parent, false)
        return DashboardViewHolder(view)
    }

   /* fun newList(historyModelsNew: ArrayList<DashboardModel>){
        historyModels = historyModelsNew
        notifyDataSetChanged()
    }*/

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        rs = context.resources.getString(R.string.rs)
        val buy: Boolean = historyModels[position].manage.equals("Buy")
        if (buy) {
            holder.tv_history_stock_manage.setText(historyModels[position].manage)
            holder.tv_history_display_name.setText(historyModels[position].stockName)
            holder.tv_history_display_number.setText(historyModels[position]
                .stockNumber)
            holder.tv_history_display_total_price.setText(rs + "" + historyModels[position]
                .stockYourPrice)
            holder.tv_history_display_price.setText(rs + "" + historyModels[position]
                .stockTotalPrice)
            holder.tv_history_display_price.setBackgroundResource(R.drawable.button_text_design_red)
        } else {
            holder.tv_history_stock_manage.text = historyModels[position].manage
            holder.tv_history_display_name.text = historyModels[position].stockName
            holder.tv_history_display_number.text = historyModels[position]
                .stockNumber
            holder.tv_history_display_total_price.text = rs + "" + historyModels[position]
                .stockYourPrice
            holder.tv_history_display_price.text = rs + "" + historyModels[position]
                .stockTotalPrice
            holder.tv_history_display_price.setBackgroundResource(R.drawable.button_text_design_green)
        }

        holder.card_history.setOnClickListener(View.OnClickListener {
            val category_id: Int = historyModels[position].id
            Log.d("deletd_id5", "" + category_id)
            val popupMenu = PopupMenu(context, holder.card_history)
            popupMenu.inflate(R.menu.cardview_menu)
            popupMenu.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.cv_update -> {
                        val intent = Intent(context, DashboardUpdate::class.java)
                        val bundle = Bundle()
                        bundle.putString(DatabaseHelper.MANAGEMENT_STOCK_ID,
                            java.lang.String.valueOf(
                                historyModels[position].id))
                        bundle.putString(DatabaseHelper.MANAGEMENT_CATEGORY_ID,
                            java.lang.String.valueOf(
                                historyModels[position].category_id))
                        Log.d("category_bundle_id", "" + historyModels[position].id)
                        Log.d("category_bundle_id1",
                            "" + historyModels[position].category_id)
                        bundle.putString("valueOfRadioDashboard", historyModels[position].manage)
                        Log.d("valueOfRadioDashboard", "" + historyModels[position].manage)
                        bundle.putString("stock_name", historyModels[position].stockName)
                        bundle.putString("stock_number", historyModels[position].stockNumber)
                        bundle.putString("stock_current_price",
                            historyModels[position].stockCurrentPrice)
                        bundle.putString("stock_your_price", historyModels[position].stockYourPrice)
                        bundle.putString("stock_total_price", historyModels[position].stockTotalPrice)
                        bundle.putString("stock_description", historyModels[position].description)
                        intent.putExtras(bundle)
                        Log.d("stock", "" + bundle)
                        context.startActivity(intent)
                        (context as AppCompatActivity).finish()
                    }
                }
                false
            }
            popupMenu.show()
        })

    }

    fun removeItem(position: Int,reg_id : Int) {
        val id1: Int = historyModels[position].id
        Log.d("deleted_id", "" + id1)
        databaseHelper = DatabaseHelper(context)
        databaseHelper!!.deleteInformationFromManagement(id1.toString(),reg_id)
        //historyModels.remove(i);
        notifyItemRangeChanged(position, historyModels.size)
        historyModels.removeAt(position)
        notifyItemRemoved(position)
        notifyDataSetChanged()

    }

    override fun getItemCount(): Int {

        return historyModels.size
    }
    fun getData(): ArrayList<DashboardModel> {
        return historyModels
    }

    class DashboardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_history_display_name: MaterialTextView
        var tv_history_display_number: MaterialTextView
        var tv_history_display_total_price: MaterialTextView
        var tv_history_display_price: MaterialTextView
        var tv_history_stock_manage: MaterialTextView
        var card_history: CardView

        init {
            tv_history_display_name = itemView.findViewById(R.id.tv_history_display_name)
            tv_history_display_number = itemView.findViewById(R.id.tv_history_display_number)
            tv_history_display_total_price =
                itemView.findViewById(R.id.tv_history_display_total_price)
            tv_history_display_price = itemView.findViewById(R.id.tv_history_display_price)
            tv_history_stock_manage = itemView.findViewById(R.id.tv_history_stock_manage)
            card_history = itemView.findViewById(R.id.card_history)

        }
    }
}
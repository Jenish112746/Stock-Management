package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.sessionManager.SessionManager
import com.example.new_stock_app.utility.InputValidation
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import com.shashank.sony.fancytoastlib.FancyToast

class MainActivity : AppCompatActivity() {

    private var tv_email: TextInputLayout? = null
    private var tv_username: TextInputLayout? = null
    private var tv_password: TextInputLayout? = null
    private var tv_confrim_password: TextInputLayout? = null
    private var tv_mobile: TextInputLayout? = null
    var btn_register_register: MaterialButton? = null
    var btn_login_register: MaterialButton? = null
    var tv_or: MaterialTextView? = null
    var databaseHelper: DatabaseHelper? = null
    var email: String? = null
    var username: String? = null
    var password: String? = null
    var mobile: String? = null
    var sessionManager: SessionManager? = null
    private lateinit var inputValidation: InputValidation
    var ie_email:TextInputEditText? = null
    var ie_username:TextInputEditText? = null
    var ie_password:TextInputEditText? = null
    var ie_con_password:TextInputEditText? = null
    var ie_m_number:TextInputEditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        databaseHelper = DatabaseHelper(this)
        inputValidation = InputValidation(this)

        tv_email = findViewById(R.id.ti_email)
        tv_username = findViewById(R.id.ti_username)
        tv_password = findViewById(R.id.ti_password)
        tv_confrim_password = findViewById(R.id.ti_con_password)
        tv_mobile = findViewById(R.id.ti_mobile_no)
        btn_register_register = findViewById(R.id.btn_register_register)
        btn_login_register = findViewById(R.id.btn_login_register)
        tv_or = findViewById(R.id.tv_or)
        ie_email = findViewById(R.id.tv_email)
        ie_username = findViewById(R.id.tv_username)
        ie_password = findViewById(R.id.tv_password)
        ie_con_password = findViewById(R.id.tv_confirm_password)
        ie_m_number = findViewById(R.id.tv_mobile)

        sessionManager = SessionManager(applicationContext)


        btn_register_register!!.setOnClickListener(View.OnClickListener {

            if (!inputValidation.isInputEditTextEmail(ie_email!!,
                    tv_email!!,
                    getString(R.string.error_message_email))
            ) {
                return@OnClickListener
            }else{

                    email = tv_email!!.editText!!.text.toString().trim { it <= ' ' }
                    Log.e("GETEMAIL","--->>"+email)


            }
            if (!inputValidation.isInputEditTextFilled(ie_username!!,
                    tv_username!!,
                    getString(R.string.error_message_name))
            ) {
                return@OnClickListener
            }else{
                username = tv_username!!.editText!!.text.toString().trim { it <= ' ' }
                Log.e("GETEUserNAMe","--->>"+username)
            }
            if (!inputValidation.isInputEditTextMatches(ie_password!!, ie_con_password!!,
                    tv_confrim_password!!, getString(R.string.error_password_match))
            ) {
                return@OnClickListener
            }else{
                password = tv_password!!.editText!!.text.toString().trim { it <= ' ' }
                Log.e("GETEMAIL","--->>"+password)
            }
            if (!inputValidation.isInputEditTextMobile(ie_m_number!!,
                    tv_mobile!!,
                    getString(R.string.error_message_mobile_number))
            ) {
                return@OnClickListener
            }else{
                mobile = tv_mobile!!.editText!!.text.toString().trim { it <= ' ' }
                Log.e("GETEMAIL","--->>"+mobile)
            }

            val isInserted = databaseHelper!!.insertRegisterData(email, username, password, mobile)

            if (isInserted == true) {
                FancyToast.makeText(this@MainActivity, "Registration Successful", FancyToast.LENGTH_SHORT,FancyToast.SUCCESS,true).show()
                startActivity(Intent(this@MainActivity, LoginActivity::class.java))
                finish()

            } else {
                FancyToast.makeText(this@MainActivity,
                    getString(R.string.error_email_exists), FancyToast.LENGTH_SHORT,FancyToast.ERROR,true).show()
            }
        })

        btn_login_register!!.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
            finish()
        })
        tv_password!!.setEndIconOnClickListener {

            val editText = tv_password!!.editText
            val editText1 = tv_confrim_password!!.editText
            val oldSelection = editText!!.selectionEnd
            val oldSelection1 = editText1!!.selectionEnd
            val hidePassword = editText.transformationMethod !is PasswordTransformationMethod
            val hidePassword1 = editText1.transformationMethod !is PasswordTransformationMethod
            ie_password!!.transformationMethod = PasswordTransformationMethod.getInstance().takeIf { hidePassword }
            ie_con_password!!.transformationMethod = PasswordTransformationMethod.getInstance().takeIf { hidePassword1 }

            if (oldSelection >= 0) {
                ie_password!!.setSelection(oldSelection)
                ie_con_password!!.setSelection(oldSelection1)
            }

        }

    }

    fun confirmInput(view: View?) {
        if (!validateEmail() or !validateUsername() or !validatePassword() or !validateMobile()) {
            return
        }
        var input = "Email:" + tv_email!!.editText!!.text.toString()
        input += "\n"
        input += "Username:" + tv_username!!.editText!!.text.toString()
        input += "\n"
        input += "Password:" + tv_password!!.editText!!.text.toString()
        input += "\n"
        input += "Mobile:" + tv_mobile!!.editText!!.text.toString()
        input += "\n"
        input += "Confirm Password:" + tv_confrim_password!!.editText!!.text.toString()
        Toast.makeText(this, input, Toast.LENGTH_SHORT).show()
    }

    private fun validateMobile(): Boolean {
        val mobileInput = tv_mobile!!.editText!!.text.toString().trim { it <= ' ' }
        return if (mobileInput.isEmpty()) {
            tv_mobile!!.error = "Please Enter Your MobileNo."
            false
        } else {
            tv_mobile!!.error = null
            true
        }
    }

    private fun validatePassword(): Boolean {
        val confirmpasswordInput =
            tv_confrim_password!!.editText!!.text.toString().trim { it <= ' ' }
        val passwordInput = tv_password!!.editText!!.text.toString().trim { it <= ' ' }
        return if (passwordInput.isEmpty() && confirmpasswordInput.isEmpty()) {
            tv_password!!.error = "Please Enter Your Password"
            tv_confrim_password!!.error = "Please Enter Confirm Password"
            false
        } else if (passwordInput != confirmpasswordInput) {
            tv_confrim_password!!.error = "Confirm Password Doesn't Match"
            false
        } else {
            tv_password!!.error = null
            tv_confrim_password!!.error = null
            true
        }
    }

    private fun validateUsername(): Boolean {
        val usernameInput = tv_username!!.getEditText()!!.text.toString().trim { it <= ' ' }
        return if (usernameInput.isEmpty()) {
            tv_username!!.setError("Please Enter Your Username")
            false
        } else {
            tv_username!!.setError(null)
            true
        }
    }

    private fun validateEmail(): Boolean {
        val emailInput = tv_email!!.getEditText()!!.text.toString().trim { it <= ' ' }
        return if (emailInput.isEmpty()) {
            tv_email!!.setError("Please Enter Your Email")
            false
        } else {
            tv_email!!.setError(null)
            true
        }
    }


}
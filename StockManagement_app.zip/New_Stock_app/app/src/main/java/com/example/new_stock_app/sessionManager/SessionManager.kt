package com.example.new_stock_app.sessionManager

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

class SessionManager(context: Context) {

    val SHARED_PREF_NAME = "com.learning.demo"
    val KEY_EMAIL = "keyemail"
    val KEY_ID = "keyid"
    val KEY_LOGGED_IN = "loggedIn"
    val KEY_LOGGED_CAT = "cat_id"
    val KEY_CATEGORY_ID = "keycategoryid"
    val KEY_MGMT_ID = "keymgmtid"
    val KEY_NAME = "keyname"
    val KEY_CURRRENT_PRICE = "keyprice"


    private var context: Context? = null
    private var sharedPreferences: SharedPreferences? = null


    fun SessionManager(context: Context) {
        this.context = context
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
    }


    fun checkLoggedIn(context1: Context): Boolean {
        sharedPreferences = context1.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences!!.getBoolean(KEY_LOGGED_IN, false)
    }


    fun isLoggedIn(id: Int, email: String?) {
        val editor = sharedPreferences!!.edit()
        editor.putString(KEY_EMAIL, email)
        editor.putInt(KEY_ID, id)
        Log.e("GETTINGKEYID","-->"+id)
        editor.putBoolean(KEY_LOGGED_IN, true)
        editor.commit()
    }



    fun iscategoryid(context1: Context , cat_id: String?, man_cat_id: String?, name: String?) {
        sharedPreferences = context1.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences!!.edit()
        editor.putString(KEY_CATEGORY_ID, cat_id)
        editor.putString(KEY_MGMT_ID, man_cat_id)
        editor.putString(KEY_NAME, name)
        editor.putBoolean(KEY_LOGGED_CAT, true)
        editor.apply()
    }

    fun currentprice(context1:Context,current_price: String?) {
        sharedPreferences = context1.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences!!.edit()
        editor.putString(KEY_CURRRENT_PRICE, current_price)
        editor.putBoolean(KEY_LOGGED_CAT, true)
        editor.apply()
    }

    fun getId(context1: Context): Int {
        sharedPreferences = context1.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences!!.getInt(KEY_ID, 0)
    }


    fun getKeyCategoryId(): String? {
        return sharedPreferences!!.getString(KEY_CATEGORY_ID, null)
    }


    fun getKeyCurrrentPrice(): String? {
        return sharedPreferences!!.getString(KEY_CURRRENT_PRICE, null)
    }

    fun getKeyMgmtId(): String? {
        return sharedPreferences!!.getString(KEY_MGMT_ID, null)
    }

    fun getKeyName(): String? {
        return sharedPreferences!!.getString(KEY_NAME, null)
    }

    fun getemail(): String? {
        return sharedPreferences!!.getString(KEY_EMAIL, null)
    }

    fun clear() {
        sharedPreferences!!.edit().clear().commit()
    }
}
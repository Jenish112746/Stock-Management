package com.example.new_stock_app.activity

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.new_stock_app.R
import com.example.new_stock_app.adapter.HistoryAdapter
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.example.new_stock_app.utility.SwipeToDelete
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textview.MaterialTextView
import java.text.DecimalFormat

class HistoryListActivity : AppCompatActivity() {

    private var rv_history_list: RecyclerView? = null
    private var historyAdapter: HistoryAdapter? = null
    private val dashboardModelArrayList: ArrayList<DashboardModel> = ArrayList<DashboardModel>()
    private var tb_history_list: Toolbar? = null
    private var databaseHelper: DatabaseHelper? = null
    private var fb_history_list: FloatingActionButton? = null
    private var category_idd: Int? = null
    var relativeLayout: RelativeLayout? = null
    private var id: String? = null
    private  var name:kotlin.String? = null
    private  var current_price:kotlin.String? = null
    private var sessionManager: SessionManager? = null
    private var tv_value_of_shares: MaterialTextView? = null
    private  var tv_investment:MaterialTextView? = null
     private  var tv_total_value:MaterialTextView? = null
    private  var tv_value_of_profit_loss:MaterialTextView? = null
    private var value = 0f
    private var stock = 0
    private var total = 0f
    private var price = 0f
    private var totalvalue = 0f
    private var buytotal = 0f
    private var selltotal = 0f
    private var buy = 0
    private var sell = 0
    private var cprice = 0.0
    private var yprice = 0.0
    private var rs: String? = null
    var historyListActivity: HistoryListActivity? = null
    var reg_id : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_list)
        databaseHelper = DatabaseHelper(this)
        historyListActivity = this
        fb_history_list = findViewById(R.id.fb_history_list)
        rs = resources.getString(R.string.rs)

        sessionManager = SessionManager(applicationContext)
        if (!sessionManager!!.checkLoggedIn(this)) {
            finish()
            return
        }
        category_idd = Integer.valueOf(sessionManager!!.getKeyCategoryId()!!)
        id = sessionManager!!.getKeyMgmtId()
        name = sessionManager!!.getKeyName()
        current_price = sessionManager!!.getKeyCurrrentPrice()
        Log.d("ses_cat_id1", "" + category_idd)
        Log.d("ses_cat_id_mg", "" + id)
        Log.d("ses_cat_name", "" + name)
        Log.d("ses_cat_cprice", "" + current_price)

        relativeLayout = findViewById(R.id.history_list_relative)
        rv_history_list = findViewById(R.id.rv_history_list)
        tv_total_value = findViewById(R.id.tv_total_value)
        tv_investment = findViewById(R.id.tv_investment)
        tv_value_of_shares = findViewById(R.id.tv_value_of_shares)
        tv_value_of_profit_loss = findViewById(R.id.tv_value_of_profit_loss)

        rv_history_list!!.setHasFixedSize(true)
        rv_history_list!!.layoutManager = LinearLayoutManager(this)

        enableSwipeToDeleteAndUndo()

        tb_history_list = findViewById(R.id.toolbar_history_list)
        tb_history_list!!.title = name
        setSupportActionBar(tb_history_list)

        fb_history_list!!.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@HistoryListActivity, HistoryActivity::class.java)
            intent.putExtra("management_category_id", category_idd)
            intent.putExtra("category_name", name)
            Log.d("result37", "" + category_idd)
            Log.d("result38", "" + name)
            startActivity(intent)
            finish()
        })

        reg_id = java.lang.String.valueOf(sessionManager!!.getId(this))
    }
    override fun onStart() {
        enableSwipeToDeleteAndUndo()
        list()
        getdata()
        super.onStart()
    }

    override fun onRestart() {
        enableSwipeToDeleteAndUndo()
        getdata()
        list()
        super.onRestart()
    }

    override fun onResume() {
        getdata()
        enableSwipeToDeleteAndUndo()
        list()
        super.onResume()
    }


    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this@HistoryListActivity, DashBoard::class.java))
        finish()
    }

    fun getdata() {
        Log.e("hvvcvhv",""+reg_id)
        buytotal = databaseHelper!!.getBuyTotalStock(category_idd!!,reg_id!!.toInt())
        selltotal = databaseHelper!!.getSellTotalStock(category_idd!!,reg_id!!.toInt())
        buy = databaseHelper!!.getBuyStock(category_idd!!,reg_id!!.toInt())
        sell = databaseHelper!!.getSellStock(category_idd!!,reg_id!!.toInt())
        cprice = databaseHelper!!.currentprice(category_idd!!,reg_id!!.toInt())
        yprice = databaseHelper!!.yourprice(category_idd!!,reg_id!!.toInt())
        Log.d("current_price", "" + cprice)
        Log.d("buy_total", "" + buytotal)
        Log.d("sell_total", "" + selltotal)
        Log.d("buy_stock", "" + buy)
        Log.d("sell_stock", "" + sell)
        Log.d("your_price", "" + yprice)
        stock = buy - sell
        total = buytotal - selltotal
        value = total / stock
        totalvalue = (stock * cprice).toFloat()
        price = totalvalue - total
        if (stock != 0) {
            if (price >= 0) {
                tv_value_of_profit_loss!!.text =
                    rs + "" + DecimalFormat("##.##").format(price.toDouble())
                tv_value_of_profit_loss!!.setTextColor(Color.GREEN)
            } else {
                tv_value_of_profit_loss!!.text =
                    rs + "" + DecimalFormat("##.##").format(price.toDouble())
                tv_value_of_profit_loss!!.setTextColor(Color.RED)
            }
            tv_value_of_shares!!.text = rs + "" + DecimalFormat("##.##").format(value.toDouble())
            tv_investment!!.text = rs + "" + DecimalFormat("##.##").format(total.toDouble())
            tv_total_value!!.text = rs + "" + DecimalFormat("##.##").format(totalvalue.toDouble())
        } else {
            total = buytotal - selltotal
            totalvalue = (stock * cprice).toFloat()
            price = totalvalue - total
            tv_investment!!.text = rs + "" + 0
            if (price >= 0) {
                tv_value_of_profit_loss!!.text =
                    rs + "" + DecimalFormat("##.##").format(price.toDouble())
                tv_value_of_profit_loss!!.setTextColor(Color.GREEN)
            } else {
                tv_value_of_profit_loss!!.text =
                    rs + "" + DecimalFormat("##.##").format(price.toDouble())
                tv_value_of_profit_loss!!.setTextColor(Color.RED)
            }
            tv_total_value!!.text = rs + "" + DecimalFormat("##.##").format(totalvalue.toDouble())
            tv_value_of_shares!!.text = rs + "" + 0
            tv_investment!!.text = rs + "" + 0
        }
        Log.d("total_stock", "" + stock)
        Log.d("total_stock_value", "" + total)
        Log.d("total_value", "" + totalvalue)
        Log.d("value_of_shares", "" + value)
        Log.d("value_of_price", "" + price)

        Log.e("HISTORYACTIVITY",""+reg_id)
        val isinserted = databaseHelper!!.updateInformationInInvestments(totalvalue.toString(),
            total.toString(),
            value.toString(),
            price.toString(),
            category_idd.toString(),
            reg_id)
        Log.d("investments", "" + isinserted)
    }

    fun list() {

        val dashboardModels = databaseHelper!!.getStockManageData(
            category_idd!!, reg_id!!)
        if (!dashboardModels.isEmpty()) {
            dashboardModelArrayList.clear()
            for (i in dashboardModels.indices) {
                Log.d("historymodelssize", "" + dashboardModels.size)
                dashboardModelArrayList.add(dashboardModels[i])
            }
        }
        if (dashboardModelArrayList.isEmpty()) {
            rv_history_list!!.adapter = null

        } else {
            historyAdapter = HistoryAdapter(dashboardModelArrayList, this)
            rv_history_list!!.adapter = historyAdapter
            historyAdapter!!.notifyDataSetChanged()
            //finish();
            Log.d("result24", "" + historyAdapter)
            Log.d("result25", "" + dashboardModelArrayList)

        }
    }
    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback: SwipeToDelete = object : SwipeToDelete(this) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                val position = viewHolder.adapterPosition
                val (category_id, id1, stockName, stockNumber, stockTotalPrice, stockCurrentPrice, stockYourPrice, manage, description) = historyAdapter!!.getData()[position]
                val builder = AlertDialog.Builder(this@HistoryListActivity)
                builder.setCancelable(false)
                    .setTitle("Are You Sure Want To Delete")
                    .setPositiveButton("Ok") { dialog, which ->
                        historyAdapter!!.removeItem(position,reg_id!!.toInt())
                        getdata()
                        list()
                        val snackbar = Snackbar
                            .make(relativeLayout!!,
                                "Item was removed from the list.",
                                Snackbar.LENGTH_LONG)
                        snackbar.show()
                    }.setNegativeButton("Cancel"
                    ) { dialog, which -> dialog.cancel()
                        historyAdapter!!.notifyDataSetChanged()
                    }.show()
            }
        }
        val itemTouchhelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(rv_history_list)
    }

    @JvmName("getHistoryListActivity1")
    fun getHistoryListActivity(): HistoryListActivity? {
        return historyListActivity
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // return super.onCreateOptionsMenu(menu);
        menuInflater.inflate(R.menu.cuurent_price, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // return super.onOptionsItemSelected(item);
        val id = item.itemId
        when (id) {
            R.id.cuurent_price -> openDialog()
            R.id.logout -> {
                startActivity(Intent(this@HistoryListActivity, LoginActivity::class.java))
                sessionManager!!.clear()
                finish()
            }
        }
        return true
    }

    private fun openDialog() {
        val alertDialog = com.example.new_stock_app.dialog.AlertDialog()
        val intent = Bundle()
        intent.putDouble("management_c_price", cprice)
        intent.putInt("management_c_id", category_idd!!)
        Log.d("ccprice", "" + cprice)
        Log.d("ccidce", "" + category_idd)
        alertDialog.setArguments(intent)
        alertDialog.show(supportFragmentManager, "AlertDialog")
    }

}
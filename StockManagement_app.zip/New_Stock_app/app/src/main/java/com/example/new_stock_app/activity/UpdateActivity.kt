package com.example.new_stock_app.activity

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout

class UpdateActivity : AppCompatActivity() {
    private var tv_id: TextInputLayout? = null
    private  var tv_update_email:TextInputLayout? = null
    private  var tv_update_username:TextInputLayout? = null
    private  var tv_update_password:TextInputLayout? = null
    private  var tv_update_mobile:TextInputLayout? = null
    private var btn_update: MaterialButton? = null
    private var databaseHelper: DatabaseHelper? = null
    var id: String? = null
    var new_email:String? = null
    var new_username:String? = null
    var new_mobile:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)
        databaseHelper = DatabaseHelper(this)

        tv_id = findViewById(R.id.tv_id)
        tv_update_email = findViewById(R.id.tv_update_email)
        tv_update_username = findViewById(R.id.tv_update_username)
        tv_update_mobile = findViewById(R.id.tv_update_mobile)
        btn_update = findViewById(R.id.btn_update)

        btn_update!!.setOnClickListener(View.OnClickListener {
            id = tv_id!!.getEditText()!!.text.toString()
            new_email = tv_update_email!!.getEditText()!!.text.toString()
            new_username = tv_update_username!!.getEditText()!!.text.toString()
            new_mobile = tv_update_mobile!!.getEditText()!!.text.toString()
            val isupdated = databaseHelper!!.updateInformationInRegister(id!!,
                new_email,
                new_username,
                new_mobile)
            if (isupdated == true) {
                Toast.makeText(this@UpdateActivity, "Data Updated Successfully", Toast.LENGTH_SHORT)
                    .show()
            } else {
                Toast.makeText(this@UpdateActivity,
                    "Data Not Updated Try Again",
                    Toast.LENGTH_SHORT).show()
            }
        })

    }
}
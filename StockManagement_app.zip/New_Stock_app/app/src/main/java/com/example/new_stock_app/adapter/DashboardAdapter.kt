package com.example.new_stock_app.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.new_stock_app.R
import com.example.new_stock_app.activity.HistoryListActivity
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.textview.MaterialTextView


class DashboardAdapter(var dashboardModelList: ArrayList<DashboardModel>, var context: Context) :
    RecyclerView.Adapter<DashboardAdapter.DashboardViewHolder>() {

     var rs: String? = null
     var databaseHelper: DatabaseHelper? = null



    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): DashboardAdapter.DashboardViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_dashboard, parent, false)

        return DashboardViewHolder(view)
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {

        val profit_loss: Float = dashboardModelList?.get(position).stockTotalPrice!!.toFloat()
        rs = context.getString(R.string.rs)

        if (profit_loss > 0) {
            holder.tv_display_name.setText(dashboardModelList!![position].stockName)
            holder.tv_display_number.setText(dashboardModelList!!.get(position).stockNumber)
            holder.tv_display_total_price.setText(rs + "" + dashboardModelList!![position].stockCurrentPrice)
            holder.tv_display_price.setBackgroundResource(R.drawable.button_text_design_green)
            holder.tv_display_price.setText(rs + "" + dashboardModelList!![position].stockTotalPrice)
        } else {
            holder.tv_display_name.setText(dashboardModelList!![position].stockName)
            holder.tv_display_number.setText(dashboardModelList?.get(position)!!.stockNumber)
            holder.tv_display_total_price.setText(rs + "" + dashboardModelList!!.get(position).stockCurrentPrice)
            holder.tv_display_price.setBackgroundResource(R.drawable.button_text_design_red)
            holder.tv_display_price.setText(rs + "" + dashboardModelList!!.get(position).stockTotalPrice)
        }
        holder.itemView.setOnClickListener(View.OnClickListener {

            Log.e("HHDVV","==?")
            val i2 = Intent(context, HistoryListActivity::class.java)
            val bundle2 = Bundle()
            val id: String = java.lang.String.valueOf(dashboardModelList[position].id)
            val mgmt_id: String = java.lang.String.valueOf(dashboardModelList[position].category_id)
            val name: String? = dashboardModelList[position].stockName
            val sessionManager = SessionManager(context)
            sessionManager.iscategoryid(context , mgmt_id, id, name)

            Log.d("result23", "MANAGEMENT_STOCK_ID : " + java.lang.String.valueOf(
                dashboardModelList[position].id))
            Log.d("result32", "MANAGEMENT_CATEGORY_ID : " + dashboardModelList[position].category_id)
            Log.d("result33", "CATEGORY_NAME : " + java.lang.String.valueOf(
                dashboardModelList[position].stockName))
            Log.d("result34", "" + bundle2)

            i2.putExtras(bundle2)
            context.startActivity(i2)
            (context as AppCompatActivity).finish()
        })

    }
    fun removeItem(position: Int,reg_id : Int) {
        val id1: Int = dashboardModelList[position].id
        val id2: Int = dashboardModelList[position].category_id
        Log.d("deleted_category_id", "" + id1)
        Log.d("deleted_managementid", "" + id2)
        databaseHelper = DatabaseHelper(context)
        databaseHelper!!.deleteInformationFromcategory(id1.toString(), id2.toString(), id2.toString(),reg_id)
        //historyModels.remove(i);
        notifyItemRangeChanged(position, dashboardModelList.size)
        dashboardModelList.removeAt(position)
        notifyItemRemoved(position)
        notifyDataSetChanged()
    }
    fun getData(): ArrayList<DashboardModel> {
        return dashboardModelList
    }

    override fun getItemCount(): Int {
        return dashboardModelList.size
    }

    class DashboardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_display_name: MaterialTextView
        var tv_display_number: MaterialTextView
        var tv_display_total_price: MaterialTextView
        var tv_display_price: MaterialTextView
        var card_linear: LinearLayout

        init {
            tv_display_name = itemView.findViewById(R.id.tv_display_name)
            tv_display_number = itemView.findViewById(R.id.tv_display_number)
            tv_display_total_price = itemView.findViewById(R.id.tv_display_total_price)
            tv_display_price = itemView.findViewById(R.id.tv_display_price)
            card_linear = itemView.findViewById(R.id.card_linear)
        }
    }
}
package com.example.new_stock_app.databasehelper

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.new_stock_app.model.DashboardModel
import java.text.DecimalFormat

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {


        val DATABASE_NAME = "stockmanagement.db"
        private const val DATABASE_VERSION = 1

        //Table Names
        val TABLE_REGISTER = "register"
        val TABLE_MANAGEMENT = "management"
        val TABLE_BUY = "buy"
        val TABLE_SELL = "sell"
        val TABLE_CATEGORY = "category"
        val TABLE_INVESTMENTS = "investments"
        val TABLE_REGISTER_MANAGEMENT = "register_management"

        //Common Column Names
        val KEY_ID = "id"
        val KEY_CREATED_AT = "created_at"

        //Register Columns
        val REGISTER_ID = "register_id"
        val REGISTER_EMAIL = "email"
        val REGISTER_USERNAME = "username"
        val REGISTER_PASSWORD = "password"
        val REGISTER_MOBILENO = "mobile"

        //Investments Tables
        val INVESTMENTS_ID = "investments_id"
        val INVESTMENT_TOTAL_VALUE = "investments"
        val INVESTMENTS_PROFIT_LOSS = "profit_loss"
        val INVESTMENTS_STOCK_RATE = "stock_value"
        val INVESTMENTS_STOCK_ID = "management_inv_id"
        val INVESTMENTS_CAT_ID = "management_cat_id"
        val INVESTMENTS_VALUE = "total_profit_loss"
        val INVESTMENTS_REGISTER_ID = "investment_reg_id"


        //Category Tables
        val CATEGORY_ID = "category_id"
        val CATEGORY_NAME = "category_name"
        val CATEGORY_REG_ID = "category_reg_id"

        //Management Columns
        val MANAGEMENT_STOCK_ID = "management_id"
        val MANAGEMENT_CATEGORY_ID = "management_category_id"
        val MANAGEMENT_STOCK_NUMBER = "stock_number"
        val MANAGEMENT_STOCK_CURRENT_PRICE = "stock_current_price"
        val MANAGEMENT_STOCK_YOUR_PRICE = "stock_your_price"
        val MANAGEMENT_STOCK_TOTAL_PRICE = "stock_total_price"
        val MANAGEMENT_STOCK_MANAGE = "stock_manage"
        val MANAGEMENT_STOCK_DESCRIPTION = "stock_description"
        val MANAGEMENT_REGISTER_ID = "management_register_id"

        //REGISTER_MANAGEMENT COLUMNS
        val KEY_REGISTER_ID = "register_id"
        val KEY_MANAGEMENT_ID = "management_id"

        //Buy Columns
        val BUY_ID = "buy_id"
        val BUY_MANAGEMENT_ID = "buy_management_id"
        val BUY_CATEGORY_ID = "buy_category_id"

        //Buy Columns
        val SELL_ID = "sell_id"
        val SELL_MANAGEMENT_ID = "sell_management_id"
        val SELL_CATEGORY_ID = "sell_category_id"
    }

    //TABLE CREATE STATEMENTS.

    val CREATE_TABLE_REGISTER = ("CREATE TABLE IF NOT EXISTS "
            + TABLE_REGISTER + "(" + REGISTER_ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + REGISTER_EMAIL + " TEXT UNIQUE,"
            + REGISTER_USERNAME + " TEXT ,"
            + REGISTER_PASSWORD + " TEXT ,"
            + REGISTER_MOBILENO + " TEXT ,"
            + KEY_CREATED_AT + " DATETIME" + ")")


    val CREATE_TABLE_MANAGEMENT = ("CREATE TABLE IF NOT EXISTS  "
            + TABLE_MANAGEMENT
            + "(" + MANAGEMENT_STOCK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," //       + CATEGORY_NAME+ " TEXT NOT NULL,"
            + MANAGEMENT_STOCK_MANAGE + " TEXT NOT NULL,"
            + MANAGEMENT_STOCK_NUMBER + " TEXT NOT NULL,"
            + MANAGEMENT_STOCK_CURRENT_PRICE + " TEXT ,"
            + MANAGEMENT_STOCK_YOUR_PRICE + " TEXT NOT NULL,"
            + MANAGEMENT_STOCK_TOTAL_PRICE + " TEXT NOT NULL,"
            + MANAGEMENT_STOCK_DESCRIPTION + " TEXT NOT NULL,"
            + MANAGEMENT_CATEGORY_ID + " INTEGER, "
            + MANAGEMENT_REGISTER_ID + " INTEGER, "
            + " FOREIGN KEY  (" + MANAGEMENT_CATEGORY_ID + ") REFERENCES " + TABLE_CATEGORY + "(" + CATEGORY_ID + "),"
            + " FOREIGN KEY  (" + MANAGEMENT_REGISTER_ID + ") REFERENCES " + TABLE_REGISTER + "(" + REGISTER_ID + "));")


    val CREATE_TABLE_INVESTMENTS = ("CREATE TABLE IF NOT EXISTS "
            + TABLE_INVESTMENTS + "(" + INVESTMENTS_ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + INVESTMENT_TOTAL_VALUE + " TEXT NOT NULL,"
            + INVESTMENTS_PROFIT_LOSS + " TEXT NOT NULL,"
            + INVESTMENTS_STOCK_RATE + " TEXT NOT NULL,"
            + INVESTMENTS_VALUE + " TEXT NOT NULL,"
            + INVESTMENTS_CAT_ID + " INTEGER, "
            + INVESTMENTS_REGISTER_ID + " INTEGER, "
            + " FOREIGN KEY  (" + INVESTMENTS_CAT_ID + ") REFERENCES " + TABLE_CATEGORY + "(" + CATEGORY_ID + "),"
            + " FOREIGN KEY  (" + INVESTMENTS_REGISTER_ID + ") REFERENCES " + TABLE_REGISTER + "(" + REGISTER_ID + "));")


    private val CREATE_TABLE_CATEGORY = ("CREATE TABLE IF NOT EXISTS "
            + TABLE_CATEGORY
            + " ( " + CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + CATEGORY_NAME + " TEXT NOT NULL ,"
            + CATEGORY_REG_ID + " INTEGER,"
            + " FOREIGN KEY  (" + CATEGORY_REG_ID + ") REFERENCES " + TABLE_REGISTER + "(" + REGISTER_ID + "));")


    private val CREATE_TABLE_MANAGEMENT_REGSITER = ("CREATE TABLE  IF NOT EXISTS "
            + TABLE_REGISTER_MANAGEMENT + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_REGISTER_ID + " INTEGER," + KEY_MANAGEMENT_ID + " INTEGER,"
            + KEY_CREATED_AT + " DATETIME" + ")")


    override fun onCreate(db: SQLiteDatabase?) {

        db!!.execSQL(CREATE_TABLE_REGISTER)
        db.execSQL(CREATE_TABLE_MANAGEMENT)
        db.execSQL(CREATE_TABLE_MANAGEMENT_REGSITER)
        db.execSQL(CREATE_TABLE_INVESTMENTS)
        db.execSQL(CREATE_TABLE_CATEGORY)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL(" DROP TABLE IF EXISTS $TABLE_REGISTER")
        db.execSQL(" DROP TABLE IF EXISTS $TABLE_MANAGEMENT")
        db.execSQL(" DROP TABLE IF EXISTS $TABLE_CATEGORY")
        db.execSQL(" DROP TABLE IF EXISTS $TABLE_REGISTER_MANAGEMENT")
        db.execSQL(" DROP TABLE IF EXISTS $TABLE_INVESTMENTS")

        onCreate(db)
    }
    fun insertRegisterData(
        email: String?,
        username: String?,
        password: String?,
        mobile: String?,
    ): Boolean {
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(REGISTER_EMAIL, email)
        contentValues.put(REGISTER_USERNAME, username)
        contentValues.put(REGISTER_PASSWORD, password)
        contentValues.put(REGISTER_MOBILENO, mobile)
        val result = sqLiteDatabase.insert(TABLE_REGISTER, null, contentValues)
        Log.d("result", "" + result)
        return if (result == -1L) {
            false
        } else {
            true
        }
    }

    fun insertCategory(name: String?, id: String?): Boolean {
        //DashboardModel dashboardModel=new DashboardModel();
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        //contentValues.put(CATEGORY_ID,id);
        contentValues.put(CATEGORY_NAME, name)
        contentValues.put(CATEGORY_REG_ID, id)
        //contentValues.put(REGISTER_MOBILENO,mobile);
        val result = sqLiteDatabase.insert(TABLE_CATEGORY, null, contentValues)
        Log.d("result1", "" + result)
        return if (result == -1L) {
            false
        } else {
            true
        }
    }

    fun insertInvestments(
        value: String?,
        profit_loss: String?,
        rate: String?,
        total_profit_loss: String?,
        management_inv_id: String?,
        management_reg_id: String?,
    ): Boolean {
        //DashboardModel dashboardModel=new DashboardModel();
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(INVESTMENT_TOTAL_VALUE, value)
        contentValues.put(INVESTMENTS_PROFIT_LOSS, profit_loss)
        contentValues.put(INVESTMENTS_STOCK_RATE, rate)
        contentValues.put(INVESTMENTS_VALUE, total_profit_loss)
        contentValues.put(INVESTMENTS_CAT_ID, management_inv_id)
        contentValues.put(INVESTMENTS_REGISTER_ID, management_reg_id)
        val result = sqLiteDatabase.insert(TABLE_INVESTMENTS, null, contentValues)
        Log.d("investments", "" + result)
        return if (result == -1L) {
            false
        } else {
            true
        }
    }

    fun updateInvestments(
        id: String,
        value: String?,
        profit_loss: String?,
        rate: String?,
        management_category_id: String?,
    ): Boolean {
        //DashboardModel dashboardModel=new DashboardModel();
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(INVESTMENT_TOTAL_VALUE, value)
        contentValues.put(INVESTMENTS_PROFIT_LOSS, profit_loss)
        contentValues.put(INVESTMENTS_STOCK_RATE, rate)
        contentValues.put(INVESTMENTS_STOCK_ID, management_category_id)
        val result =
            sqLiteDatabase.update(TABLE_INVESTMENTS, contentValues, INVESTMENTS_ID + "=" + id, null)
                .toLong()
        Log.d("investments", "" + result)
        return if (result == -1L) {
            false
        } else {
            true
        }
    }


    fun insertManagementDataFromCategory(
        categoey_id: String?,
        stock_manage: String?,
        stock_number: String?,
        stock_current_price: String?,
        stock_your_price: String?,
        stock_total_price: String?,
        description: String?,
        reg_id: String?,
    ): Boolean {
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(MANAGEMENT_CATEGORY_ID, categoey_id)
        //contentValues.put(CATEGORY_NAME, category_name);
        contentValues.put(MANAGEMENT_STOCK_MANAGE, stock_manage)
        contentValues.put(MANAGEMENT_STOCK_NUMBER, stock_number)
        contentValues.put(MANAGEMENT_STOCK_CURRENT_PRICE, stock_current_price)
        contentValues.put(MANAGEMENT_STOCK_YOUR_PRICE, stock_your_price)
        contentValues.put(MANAGEMENT_STOCK_TOTAL_PRICE, stock_total_price)
        contentValues.put(MANAGEMENT_STOCK_DESCRIPTION, description)
        contentValues.put(MANAGEMENT_REGISTER_ID, reg_id)
        val result = sqLiteDatabase.insert(TABLE_MANAGEMENT, null, contentValues)
        Log.d("result22", "" + result)
        return if (result == -1L) {
            false
        } else {
            true
        }
    }

    fun getAllData(): Cursor? {
        val sqLiteDatabase = this.writableDatabase
        return sqLiteDatabase.rawQuery("SELECT * FROM $TABLE_REGISTER", null)
    }

    fun getManagementData(): Cursor? {
        val sqLiteDatabase = this.writableDatabase
        return sqLiteDatabase.rawQuery("SELECT * FROM $TABLE_MANAGEMENT", null)
    }

    fun updateInformationInRegister(
        id: String,
        new_email: String?,
        new_username: String?,
        new_mobile: String?,
    ): Boolean {
        val sqLiteDatabase = this.writableDatabase
        val selection = "id = ?"
        val args = arrayOf(id)
        val contentValues = ContentValues()
        contentValues.put(REGISTER_ID, id)
        contentValues.put(REGISTER_EMAIL, new_email)
        contentValues.put(REGISTER_USERNAME, new_username)
        contentValues.put(REGISTER_MOBILENO, new_mobile)
        sqLiteDatabase.update(TABLE_REGISTER, contentValues, selection, args)
        return true
    }

    fun updateInformationInManagement(
        id: String,
        new_stock_manage: String?,
        new_stock_number: String?,
        new_stock_current_price: String?,
        new_stock_your_price: String?,
        new_stock_total_price: String?,
        new_description: String?,
        new_category_id: String?,
        new_register_id: String?,
    ): Boolean {
        val sqLiteDatabase = this.writableDatabase
        val selection = "id=$id"
        Log.d("id", "" + selection)
        val contentValues = ContentValues()
       contentValues.put(MANAGEMENT_STOCK_NUMBER,
            new_stock_number)
        contentValues.put(MANAGEMENT_STOCK_CURRENT_PRICE, new_stock_current_price)
        contentValues.put(MANAGEMENT_STOCK_YOUR_PRICE, new_stock_your_price)
        contentValues.put(MANAGEMENT_STOCK_TOTAL_PRICE, new_stock_total_price)
        contentValues.put(MANAGEMENT_STOCK_MANAGE, new_stock_manage)
        contentValues.put(MANAGEMENT_STOCK_DESCRIPTION, new_description)
        contentValues.put(MANAGEMENT_CATEGORY_ID, new_category_id)
        contentValues.put(MANAGEMENT_REGISTER_ID, new_register_id)
        sqLiteDatabase.update(TABLE_MANAGEMENT, contentValues, MANAGEMENT_STOCK_ID + "=" + id, null)
        return true
    }

    fun updateInformationInInvestments(
        total_value: String?,
        total: String?,
        value: String?,
        total_profit_loss: String?,
        management_cat_id: String,
        register_id: String?,
    ): Boolean {
        val sqLiteDatabase = this.writableDatabase
        val selection = "management_cat_id=$management_cat_id"
        Log.d("id", "" + selection)
        val contentValues = ContentValues()
        contentValues.put(INVESTMENT_TOTAL_VALUE,
            total_value)
        contentValues.put(INVESTMENTS_PROFIT_LOSS, total)
        contentValues.put(INVESTMENTS_STOCK_RATE, value)
        contentValues.put(INVESTMENTS_VALUE, total_profit_loss)
        contentValues.put(INVESTMENTS_REGISTER_ID, register_id)
        sqLiteDatabase.update(TABLE_INVESTMENTS,
            contentValues,
            INVESTMENTS_CAT_ID + "=" + management_cat_id,
            null)
        return true
    }

    fun deleteInformationFromManagement(id: String,reg_id: Int) {
        val sqLiteDatabase = this.writableDatabase
        val selection = "id = ?"
        val args = arrayOf(id)
        val sql = "DELETE FROM $TABLE_MANAGEMENT WHERE $MANAGEMENT_STOCK_ID = $id and $MANAGEMENT_REGISTER_ID = $reg_id"
        Log.d("sql_Delete", "" + sql)
        sqLiteDatabase.execSQL(sql)
        sqLiteDatabase.close()
    }

    fun deleteInformationFromcategory(
        id: String,
        management_category_id: String,
        investment_id: String,
        reg_id: Int
    ) {
        val sqLiteDatabase = this.writableDatabase
        val selection = "id = ?"
        val args = arrayOf(id)
        val sql = "DELETE FROM $TABLE_CATEGORY WHERE $CATEGORY_ID= $id"
        val sql1 =
            "DELETE FROM $TABLE_MANAGEMENT WHERE $MANAGEMENT_CATEGORY_ID= $management_category_id AND $MANAGEMENT_REGISTER_ID = $reg_id"
        val sql2 =
            "DELETE FROM $TABLE_INVESTMENTS WHERE $INVESTMENTS_CAT_ID= $investment_id"
        Log.d("sql_Delete", "" + sql)
        Log.d("sql_Delete1", "" + sql1)
        Log.d("sql_Delete2", "" + sql2)
        //sqLiteDatabase.delete(TABLE_MANAGEMENT,selection,new String[] {String.valueOf(id)});
        sqLiteDatabase.execSQL(sql)
        sqLiteDatabase.execSQL(sql1)
        sqLiteDatabase.execSQL(sql2)
        sqLiteDatabase.close()
    }

    fun getAllDashboardData(id: String): List<DashboardModel>? {
        val dashboardModels: MutableList<DashboardModel> = ArrayList<DashboardModel>()
        val db = this.writableDatabase

        val cursor =
            db.rawQuery("select * from management INNER join category on management_category_id=category_id WHERE management_register_id=$id group by management_category_id",
                null)

        var management_stock_id: Int
        var category_id: Int
        var manage: String
        var stock_name: String
        var buytotal: Int
        var selltotal: Int
        var result : Int
        var setStockNumber : String
        var current_price: Double
        var your_price: Double
        var stockTotalPrice : String
        var setStockCurrentPrice : String
        var setStockYourPrice: String
        var description : String
        var reg_id : Int


        if (cursor.moveToFirst()) {
            do {

                management_stock_id = cursor.getInt(cursor.getColumnIndexOrThrow(MANAGEMENT_STOCK_ID))
                category_id = cursor.getInt(cursor.getColumnIndexOrThrow(MANAGEMENT_CATEGORY_ID))
                manage = cursor.getString(cursor.getColumnIndexOrThrow(MANAGEMENT_STOCK_MANAGE))
                stock_name = cursor.getString(cursor.getColumnIndexOrThrow(CATEGORY_NAME))
                reg_id = cursor.getInt(cursor.getColumnIndexOrThrow(MANAGEMENT_REGISTER_ID))

                Log.e("MANAGEMENT_REGISTER_ID",""+reg_id)

                buytotal = getBuyStock(cursor.getInt(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_CATEGORY_ID)),reg_id)
                selltotal = getSellStock(cursor.getInt(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_CATEGORY_ID)),reg_id)

                result = buytotal - selltotal
                Log.d("rrrr", "" + buytotal)
                Log.d("rrrr1", "" + selltotal)
                setStockNumber = (DecimalFormat("##.##").format(result.toDouble()))

                current_price = currentprice(cursor.getInt(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_CATEGORY_ID)),reg_id)
                your_price = yourprice(cursor.getInt(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_CATEGORY_ID)),reg_id)
                Log.d("current_price", "" + current_price)
                Log.d("your_price_hi", "" + your_price)
                val buyfulltotal = buytotal * current_price
                val sellfulltotal = selltotal * current_price


                val result1 = buyfulltotal - sellfulltotal

                val profit_loss: Float = totalidprofitloss(cursor.getInt(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_CATEGORY_ID)))
                stockTotalPrice = (DecimalFormat("##.##").format(profit_loss.toDouble()))
                Log.d("rrrrresult", "" + result)
                Log.d("rrrrresult1", "" + result1)

               setStockCurrentPrice = (DecimalFormat("##.##").format(result1))

                setStockYourPrice = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_YOUR_PRICE)))
               description = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_DESCRIPTION)))

                val exp = DashboardModel(id = management_stock_id, category_id = category_id,
                    manage = manage,
                    stockName = stock_name,
                    stockNumber = setStockNumber,
                    stockTotalPrice = stockTotalPrice,
                    stockCurrentPrice = setStockCurrentPrice, stockYourPrice = setStockYourPrice,description=description)
                Log.e("getBuySellData", "" + exp)

                dashboardModels.add(exp)

            } while (cursor.moveToNext())

        }
        return dashboardModels
    }

    fun getStockManageData(management_category_idd: Int, reg_id: String): List<DashboardModel> {
        val dashboardModelList: MutableList<DashboardModel> = java.util.ArrayList()
        val sqLiteDatabase = this.readableDatabase
        val queuee =
            "SELECT * from category INNER join management on category.category_id=management.management_category_id WHERE category_id='$management_category_idd'AND management_register_id='$reg_id'"
        Log.d("database_helper", "" + queuee)
        Log.d("result30", "" + management_category_idd)
        val cursor = sqLiteDatabase.rawQuery(queuee, null)
        Log.d("sql", sqLiteDatabase.toString())

        var management_stock_id: Int
        var category_id: Int
        var manage: String
        var stock_name: String
        var setStockNumber : String
        var current_price: String
        var stockTotalPrice : String
        var setStockYourPrice: String
        var description : String

        if (cursor.moveToFirst()) {
            do {

                management_stock_id = (cursor.getInt(cursor.getColumnIndexOrThrow(MANAGEMENT_STOCK_ID)))
                category_id =(cursor.getInt(cursor.getColumnIndexOrThrow(MANAGEMENT_CATEGORY_ID)))
                stock_name = (cursor.getString(cursor.getColumnIndexOrThrow(CATEGORY_NAME)))
                manage= (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_MANAGE)))
                setStockNumber = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_NUMBER)))
                stockTotalPrice = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_TOTAL_PRICE)))
                current_price = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_CURRENT_PRICE)))
                setStockYourPrice = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_YOUR_PRICE)))
                description = (cursor.getString(cursor.getColumnIndexOrThrow(
                    MANAGEMENT_STOCK_DESCRIPTION)))

                val exp = DashboardModel(id = management_stock_id, category_id = category_id,
                    manage = manage,
                    stockName = stock_name,
                    stockNumber = setStockNumber,
                    stockTotalPrice = stockTotalPrice,
                    stockCurrentPrice = current_price, stockYourPrice = setStockYourPrice,description=description)

                dashboardModelList.add(exp)

            } while (cursor.moveToNext())

        }
        return dashboardModelList
    }

    fun getUser(email: String, password: String): Boolean {
        val query =
            "select  * from $TABLE_REGISTER where $REGISTER_EMAIL = '$email' and $REGISTER_PASSWORD = '$password'"
        val sqLiteDatabase = this.readableDatabase
        val cursor = sqLiteDatabase.rawQuery(query, null)
        cursor.moveToFirst()
        if (cursor.count > 0) {
            return true
        }
        cursor.close()
        return false
    }

    fun getUserID(name: String): String? {
        val sqLiteDatabase = this.readableDatabase

        val cursor =
            sqLiteDatabase.rawQuery("select category_id from category where category_name = '$name'",
                null)

        if (cursor.moveToFirst()) {

            do {
                val iid = cursor.getColumnIndex("category_id")
                val category_id = cursor.getString(iid)
                Log.d("result14", "" + category_id)
                return category_id

            } while (cursor.moveToNext())

        } else {
            return null
        }
    }

    fun getRegisterUserID(email: String): String? {
        val sqLiteDatabase = this.readableDatabase

        val cursor =
            sqLiteDatabase.rawQuery("select register_id from register where email = '$email'", null)

        if (cursor.moveToFirst()) {

            do {
                val iid = cursor.getColumnIndex("register_id")
                val register_id = cursor.getString(iid)
                Log.d("register_id", "" + register_id)
                return register_id

            } while (cursor.moveToNext())

        } else {
            return null
        }
    }

    fun getManagementId(id: Int): String? {
        val sqLiteDatabase = this.readableDatabase

        val cursor =
            sqLiteDatabase.rawQuery("SELECT management_id from management INNER join category on category.category_id=management.management_category_id WHERE category_id='$id'",
                null)

        if (cursor.moveToFirst()) {

            do {
                val iid = cursor.getColumnIndex("management_id")
                val category_id = cursor.getString(iid)
                Log.d("buydata1", "" + category_id)
                return category_id

            } while (cursor.moveToNext())

        } else {
            return null
        }
    }

    fun updateCurrentPrice(management_category_id: Int, current_price: String?,reg_id:Int): Boolean {
        val sqLiteDatabase = this.writableDatabase

        val selection = "management_category_id=$management_category_id and management_register_id='$reg_id'"
        Log.d("id_current_price", "" + selection)
        //String args= management_category_id;
        val contentValues = ContentValues()

        contentValues.put(MANAGEMENT_STOCK_CURRENT_PRICE, current_price)
        sqLiteDatabase.update(TABLE_MANAGEMENT,
            contentValues,
            selection,
            null)
        return true

    }

    fun getBuyStock(id: Int,register_id: Int
    ): Int {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(stock_number) as Total from management WHERE stock_manage='Buy' and management_category_id=$id and management_register_id=$register_id"

        //String que="SELECT  sum(stock_number) from management where stock_manage='Sell' and management_category_id=4";
        Log.d("total5", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total = cursor.getInt(cursor.getColumnIndexOrThrow("Total"))
                Log.d("tttt", "" + total)
                return total
            } while (cursor.moveToNext())
        } else {
            return 0
        }
    }

    fun getSellStock(id: Int,reg_id: Int): Int {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(stock_number) as Total from management WHERE stock_manage='Sell' and management_category_id=$id and management_register_id='$reg_id'"

        Log.d("total5", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total = cursor.getInt(cursor.getColumnIndexOrThrow("Total"))
                Log.d("tttt", "" + total)
                return total
            } while (cursor.moveToNext())
        } else {
            return 0
        }
    }

    fun currentprice(id: Int,reg_id: Int): Double {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT stock_current_price from management WHERE management_category_id=$id and management_register_id='$reg_id' "

        Log.d("total5", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total = cursor.getDouble(cursor.getColumnIndexOrThrow("stock_current_price"))
                Log.d("tttt", "" + total)
                return total
            } while (cursor.moveToNext())
        } else {
            return 0.0
        }
    }

    fun yourprice(id: Int,reg_id: Int): Double {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT stock_your_price from management WHERE management_category_id=$id and management_register_id='$reg_id'"

        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total = cursor.getDouble(cursor.getColumnIndexOrThrow("stock_your_price"))
                Log.d("tttt", "" + total)
                return total
            } while (cursor.moveToNext())
        } else {
            return 0.0
        }
    }

    fun getBuyTotalStock(id: Int,reg_id: Int): Float {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(stock_total_price) as total_price FROM management WHERE stock_manage='Buy' and management_category_id=$id and management_register_id='$reg_id'"

        Log.d("total_price1", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total_price = cursor.getFloat(cursor.getColumnIndexOrThrow("total_price"))
                Log.d("total_price", "" + total_price)
                return total_price
            } while (cursor.moveToNext())
        } else {
            return 0f
        }
    }

    fun getSellTotalStock(id: Int,reg_id: Int): Float {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(stock_total_price) as total_price FROM management WHERE stock_manage='Sell' and management_category_id=$id and management_register_id='$reg_id'"

        Log.d("total_price1", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total_price = cursor.getFloat(cursor.getColumnIndexOrThrow("total_price"))
                Log.d("total_price", "" + total_price)
                return total_price
            } while (cursor.moveToNext())
        } else {
            return 0f
        }
    }

    fun totalInvestments(id: String): Float {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(investments) as total_investments from investments where investment_reg_id=$id"

        Log.d("total_invesments", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total_price = cursor.getFloat(cursor.getColumnIndexOrThrow("total_investments"))
                Log.d("total_investments", "" + total_price)
                return total_price
            } while (cursor.moveToNext())
        } else {
            return 0f
        }
    }

    fun totalprofitloss(id: String): Float {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT sum(total_profit_loss) as total_pl from investments where investment_reg_id=$id"

        Log.d("total_profit_loss", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {
                val total_price = cursor.getFloat(cursor.getColumnIndexOrThrow("total_pl"))
                Log.d("total_pl", "" + total_price)
                return total_price
            } while (cursor.moveToNext())
        } else {
            return 0f
        }
    }

    fun totalidprofitloss(id: Int): Float {
        val sqLiteDatabase = this.writableDatabase
        val que =
            "SELECT total_profit_loss as total_pls from investments where management_cat_id=$id"

        Log.d("total_profit_loss", "" + que)
        val cursor = sqLiteDatabase.rawQuery(que, null)
        if (cursor.moveToFirst()) {
            do {

                val total_price = cursor.getFloat(cursor.getColumnIndexOrThrow("total_pls"))
                Log.d("total_pl", "" + total_price)
                return total_price
            } while (cursor.moveToNext())
        } else {
            return 0f
        }
    }


}
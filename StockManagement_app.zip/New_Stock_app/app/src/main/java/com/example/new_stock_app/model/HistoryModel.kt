package com.example.new_stock_app.model

data class HistoryModel(
    val id: Int,
    val category_id: Int,
    val stock_name: String,
    val stock_current_price: String,
    val stock_number: String,
    val stock_total_price: String,
)

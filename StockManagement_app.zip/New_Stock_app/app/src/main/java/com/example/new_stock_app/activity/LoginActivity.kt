package com.example.new_stock_app.activity

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.shashank.sony.fancytoastlib.FancyToast

class LoginActivity : AppCompatActivity() {

    private var tv_email: TextInputLayout? = null
    private  var tv_password:TextInputLayout? = null
    var btn_login_login: MaterialButton? = null
    var btn_register_login:MaterialButton? = null
    var tv_or: MaterialTextView? = null
    var databaseHelper: DatabaseHelper? = null
    var email: String? = null
    var password:kotlin.String? = null
    var sessionManager: SessionManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        databaseHelper = DatabaseHelper(this)

        tv_email = findViewById(R.id.tv_email)
        tv_password = findViewById(R.id.tv_password)
        btn_login_login = findViewById(R.id.btn_login_login)
        btn_register_login = findViewById(R.id.btn_register_login)
        tv_or = findViewById(R.id.tv_or)

        sessionManager = SessionManager(applicationContext)

        if (sessionManager!!.checkLoggedIn(this)) {
            startActivity(Intent(this@LoginActivity, DashBoard::class.java))
            finish()
            return
        }

        btn_login_login!!.setOnClickListener(View.OnClickListener {

            email = tv_email!!.editText!!.text.toString().trim { it <= ' ' }
            password = tv_password!!.editText!!.text.toString().trim { it <= ' ' }
            val isExist = databaseHelper!!.getUser(email!!, password!!)
            val register_id = databaseHelper!!.getRegisterUserID(email!!)
            Log.d("register_id1", "" + register_id)
            if (email == "") {
                FancyToast.makeText(this@LoginActivity,
                    "Please Enter Your Email ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else if (password == "") {
                FancyToast.makeText(this@LoginActivity,
                    "Please Enter Your Password",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else {
                if (isExist == true) {
                    sessionManager!!.isLoggedIn(register_id!!.toInt(), email)
                    FancyToast.makeText(this, "Login Successful", FancyToast.LENGTH_SHORT,FancyToast.SUCCESS,true).show()
                    startActivity(Intent(this@LoginActivity, DashBoard::class.java))
                    finish()
                } else {
                    FancyToast.makeText(this@LoginActivity,
                        "Username Or Password Dosent Match",
                        FancyToast.LENGTH_SHORT,
                        FancyToast.ERROR, true).show()
                }
            }
        })

        btn_register_login!!.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@LoginActivity, MainActivity::class.java))
            finish()
        })
    }

         fun isLoggedIn(id: Int, email: String) {
            sessionManager!!.isLoggedIn(id, email)
        }
         fun validateEmail(): Boolean {
            val emailInput = tv_email!!.getEditText()!!.text.toString().trim { it <= ' ' }
            return if (emailInput.isEmpty()) {
                tv_email!!.setError("Please Enter Your Email")
                false
            } else {
                tv_email!!.error = null
                true
            }
        }
         fun validatePassword(): Boolean {
            val passwordInput = tv_password!!.getEditText()!!.text.toString().trim { it <= ' ' }
            return if (passwordInput.isEmpty()) {
                tv_password!!.setError("Please Enter Your Password")
                false
            } else {
                tv_password!!.setError(null)
                true
            }
        }
    fun loginInput(view: View?) {
        if (!validateEmail() or !validatePassword()) {
            return
        }
        var input = "Email:" + tv_email!!.editText!!.text.toString()
        input += "\n"
        input += "Password:" + tv_password!!.editText!!.text.toString()
        input += "\n"
        FancyToast.makeText(this@LoginActivity, input, FancyToast.LENGTH_SHORT, FancyToast.INFO,true).show()
    }
}
package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.new_stock_app.R
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.button.MaterialButton

class ChooseActivity : AppCompatActivity() {
    var btn_choose_buy: MaterialButton? = null
    var btn_choose_sell:MaterialButton? = null
    var sessionManager: SessionManager? = null
    private var tb_choose: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose)

        tb_choose = findViewById(R.id.toolbar_choose)
        btn_choose_buy = findViewById(R.id.btn_choose_buy)
        btn_choose_sell = findViewById(R.id.btn_choose_sell)

        tb_choose!!.setTitle("Demo")
        setSupportActionBar(tb_choose)

        sessionManager = SessionManager(applicationContext)

        btn_choose_buy!!.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@ChooseActivity, DashBoard::class.java)
            intent.putExtra("stock_manage", "Buy")
            Log.d("stock_manage1", "" + intent.toString())
            startActivity(intent)
        })


        btn_choose_sell!!.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@ChooseActivity, DashBoard::class.java)
            intent.putExtra("stock_manage", "Sell")
            Log.d("stock_manage", "" + intent.toString())
            startActivity(intent)
        })
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            R.id.logout -> {
                startActivity(Intent(this@ChooseActivity, LoginActivity::class.java))
                //viewAll();
                sessionManager!!.clear()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
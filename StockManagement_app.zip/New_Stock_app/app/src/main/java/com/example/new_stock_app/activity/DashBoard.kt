package com.example.new_stock_app.activity

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.new_stock_app.R
import com.example.new_stock_app.adapter.DashboardAdapter
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.example.new_stock_app.utility.SwipeToDelete
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textview.MaterialTextView
import java.text.DecimalFormat

class DashBoard : AppCompatActivity() {

    private var fb_dashboard: FloatingActionButton? = null
    private var recycler_dashboard: RecyclerView? = null
    private var dashboardAdapter: DashboardAdapter? = null
    private val dashboardModelList: ArrayList<DashboardModel> = ArrayList<DashboardModel>()
    var tb_dashboard: Toolbar? = null
    private var databaseHelper: DatabaseHelper? = null
    private var sessionManager: SessionManager? = null
    private var investments = 0f
    private var profit_loss = 0f
    private var rs: String? = null
    private var reg_id: String? = null
    private var relativeLayout: RelativeLayout? = null
    private var tv_investments: MaterialTextView? = null
    private var tv_profit_loss: MaterialTextView? = null
    private var tv_toal: MaterialTextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)
        databaseHelper = DatabaseHelper(this)

        tv_investments = findViewById(R.id.tvd_total_value)
        tv_profit_loss = findViewById(R.id.tvd_profit_loss)
        tv_toal = findViewById(R.id.tvd_total)
        tb_dashboard = findViewById(R.id.toolbar_dashboard)
        tb_dashboard!!.title = "Stock Profit Calculator"
        setSupportActionBar(tb_dashboard)
        relativeLayout = findViewById(R.id.relative_dashboard)
        fb_dashboard = findViewById(R.id.fb_dashboard)

        fb_dashboard!!.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this, DashboardEdit::class.java))
            finish()
        })
        recycler_dashboard = findViewById(R.id.recycler_dashboard)
        recycler_dashboard!!.setHasFixedSize(true)
        recycler_dashboard!!.layoutManager = LinearLayoutManager(this)

        sessionManager = SessionManager(applicationContext)

        if (!sessionManager!!.checkLoggedIn(this)) {
            finish()
            return
        }
        rs = resources.getString(R.string.rs)
        reg_id = java.lang.String.valueOf(sessionManager!!.getId(this))

    }
    override fun onStart() {
        super.onStart()
        enableSwipeToDeleteAndUndo()
        dashboarddata()
        resume()
    }

    override fun onResume() {
        super.onResume()
        enableSwipeToDeleteAndUndo()
        dashboarddata()
        resume()
        //  finish();
    }

    override fun onRestart() {
        super.onRestart()
        enableSwipeToDeleteAndUndo()
        dashboarddata()
        resume()
    }

    private fun resume() {
        investments = databaseHelper!!.totalInvestments(reg_id!!)
        profit_loss = databaseHelper!!.totalprofitloss(reg_id!!)
        if (profit_loss >= 0) {
            val total = investments - profit_loss
            tv_investments!!.text = rs + "" + DecimalFormat("##.##").format(total.toDouble())
            tv_profit_loss!!.text = rs + "" + DecimalFormat("##.##").format(profit_loss.toDouble())
            tv_profit_loss!!.setTextColor(Color.GREEN)
            tv_toal!!.text = rs + "" + DecimalFormat("##.##").format(investments.toDouble())
        } else {
            val total = investments - profit_loss
            tv_investments!!.text = rs + "" + DecimalFormat("##.##").format(total.toDouble())
            tv_profit_loss!!.text = rs + "" + DecimalFormat("##.##").format(profit_loss.toDouble())
            tv_profit_loss!!.setTextColor(Color.RED)
            tv_toal!!.text = rs + "" + DecimalFormat("##.##").format(investments.toDouble())
        }
    }

    private fun dashboarddata() {
        val dashboardModels = databaseHelper!!.getAllDashboardData(
            reg_id!!)
        if (!dashboardModels!!.isEmpty()) {
            dashboardModelList.clear()
            for (i in dashboardModels.indices) {
                Log.d("dashboardmodelssize", "" + dashboardModels[i].category_id)
                Log.d("dashboardmodelsname", "" + dashboardModels[i].stockName)
                dashboardModelList.add(dashboardModels[i])
            }
        }
        if (dashboardModelList.isEmpty()) {
            recycler_dashboard!!.adapter = null
        } else {
            dashboardAdapter = DashboardAdapter(dashboardModelList,this)
            recycler_dashboard!!.adapter = dashboardAdapter
            dashboardAdapter!!.notifyDataSetChanged()
            Log.d("AAAA", "" + dashboardAdapter)
            Log.d("bbbb", "" + dashboardModelList.size)
        }
    }

    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback: SwipeToDelete = object : SwipeToDelete(this) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                val position = viewHolder.adapterPosition
                val (category_id, id, stockName, stockNumber, stockTotalPrice, stockCurrentPrice, stockYourPrice, manage, description) = dashboardAdapter!!.getData()!![position]
                val builder = MaterialAlertDialogBuilder(this@DashBoard)
                builder.setCancelable(false)
                    .setTitle("Are You Sure Want To Delete")
                    .setPositiveButton("Ok") { dialog, which ->
                        dashboardAdapter!!.removeItem(position,reg_id!!.toInt())
                        resume()
                        dashboarddata()
                        val snackbar = Snackbar
                            .make(relativeLayout!!,
                                "Item was removed from the list.",
                                Snackbar.LENGTH_LONG)
                        snackbar.show()
                    }.setNegativeButton("Cancel"
                    ) { dialog, which -> dialog.cancel()
                        dashboardAdapter!!.notifyDataSetChanged()
                    }.show()
            }
        }
        val itemTouchhelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(recycler_dashboard)
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            R.id.logout -> {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                sessionManager!!.clear()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        finish()
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
    }


    fun viewAll() {
        val result = databaseHelper!!.getManagementData()
        if (result!!.count == 0) {
            //show Meassage
            showMeassage("No Data", "Enter A New Record")
            return
        }
        val stringBuffer = StringBuffer()
        while (result.moveToNext()) {
            stringBuffer.append("""
    Id:${result.getString(0)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Manage:${result.getString(1)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Name:${result.getString(2)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Number:${result.getString(3)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Current Price:${result.getString(4)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Your Price:${result.getString(5)}
    
    """.trimIndent())
            stringBuffer.append("""
    Stock Total Price:${result.getString(6)}
   
    """.trimIndent())
        }
        showMeassage("Data", stringBuffer.toString())
    }

    fun showMeassage(title: String?, Message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(Message)
        builder.show()
    }

}
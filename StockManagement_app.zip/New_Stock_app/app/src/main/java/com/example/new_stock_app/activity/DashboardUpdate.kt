package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.shashank.sony.fancytoastlib.FancyToast
import java.text.DecimalFormat

class DashboardUpdate : AppCompatActivity() {
    private var btn_dashboard_update: MaterialButton? = null
    private var tv_update_stock_name: TextInputLayout? = null
    private var tv_update_total_number_stock: TextInputLayout? = null
    private var tv_update_dashboard_total_price: TextInputLayout? = null
    private var tv_dashboard_update_description: TextInputLayout? = null
    private var et_update_dashboard_total_price: TextInputEditText? = null
    private var et_update_dashboard_number: TextInputEditText? = null
    private var et_dashboard_update_your_price: TextInputEditText? = null
    private var et_dashboard_update_current_price: TextInputEditText? = null
    private var et_dashboard_update_stock_name: TextInputEditText? = null
    private var et_dashboard_update_description: TextInputEditText? = null
    private var tv_update_dashboard_your_price: TextInputLayout? = null
    private val tv_update_dashboard_current_price: TextInputLayout? = null
    private val dashboardModelArrayList: ArrayList<DashboardModel>? = null
    private var rg_dashboard_update: RadioGroup? = null
    private var radio_buy_update: RadioButton? = null
    private var radio_sell_update: RadioButton? = null
    private var update_stock_id: String? = null
    private var update_valueOfRadioDashboard: kotlin.String? = null
    private var update_stock_name: kotlin.String? = null
    private var update_stock_number: kotlin.String? = null
    private var update_stock_current_price: kotlin.String? = null
    private var update_stock_your_price: kotlin.String? = null
    private var update_stock_total_price: kotlin.String? = null
    private var update_description: kotlin.String? = null
    private var databaseHelper: DatabaseHelper? = null
    private var dashboardModel: DashboardModel? = null
    private var toolbar_dashboard_update: Toolbar? = null
    private val mdToast: FancyToast? = null
    private var sessionManager: SessionManager? = null
    private var update_category_id: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_update)

        databaseHelper = DatabaseHelper(this)
        dashboardModel = DashboardModel()
        sessionManager = SessionManager(applicationContext)

        if (!sessionManager!!.checkLoggedIn(this)) {
            finish()
            return
        }
        tv_update_stock_name = findViewById(R.id.tv_update_stock_name)
        tv_update_total_number_stock = findViewById(R.id.tv_update_total_number_stock)
        tv_update_dashboard_total_price = findViewById(R.id.tv_update_dashboard__total_price)
        tv_update_dashboard_your_price = findViewById(R.id.tv_update_dashboard__your_price)
        btn_dashboard_update = findViewById(R.id.btn_dashboard_update)
        toolbar_dashboard_update = findViewById(R.id.toolbar_dashboard_update)
        et_dashboard_update_stock_name = findViewById(R.id.et_update_stock_name)
        et_update_dashboard_total_price = findViewById(R.id.et_update_dashboard_price)
        et_dashboard_update_your_price = findViewById(R.id.et_update_dashboard__your_price)
        et_update_dashboard_number = findViewById(R.id.et_update_dashboard_number)
        tv_dashboard_update_description = findViewById(R.id.tv_dashboard_update_description)
        et_dashboard_update_description = findViewById(R.id.et_dashboard_update_description)
        rg_dashboard_update = findViewById(R.id.radiogroup_dashboard_update)
        radio_buy_update = findViewById(R.id.radio_buy_update)
        radio_sell_update = findViewById(R.id.radio_sell_update)

        setSupportActionBar(toolbar_dashboard_update)
        toolbar_dashboard_update!!.title = update_stock_name
        toolbar_dashboard_update!!.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp)

        toolbar_dashboard_update!!.setNavigationOnClickListener {
            startActivity(Intent(this@DashboardUpdate, DashBoard::class.java))
            finish()
        }
        getIncomingIntent()

        btn_dashboard_update!!.setOnClickListener(View.OnClickListener {
            if (rg_dashboard_update!!.getCheckedRadioButtonId() == -1) {
                FancyToast.makeText(this@DashboardUpdate,
                    "Please Select Your Condition ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_update_stock_name!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardUpdate,
                    "Please Enter Stock Name ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_update_total_number_stock!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardUpdate,
                    "Please Enter Number Of Stock ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            }
            else if (tv_update_dashboard_your_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardUpdate,
                    "Please Enter Stock Your Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_update_dashboard_total_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardUpdate,
                    "Please Enter Stock Total Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            }
            else {
                update_valueOfRadioDashboard =
                    (findViewById<View>(rg_dashboard_update!!.getCheckedRadioButtonId()) as RadioButton).text.toString()
                //update_stock_name = tv_update_stock_name.getEditText().getText().toString();
                update_stock_number = tv_update_total_number_stock!!.getEditText()!!.text.toString()
                //update_stock_current_price = tv_update_dashboard_current_price.getEditText().getText().toString();
                update_stock_your_price =
                    tv_update_dashboard_your_price!!.getEditText()!!.text.toString()
                update_stock_total_price =
                    tv_update_dashboard_total_price!!.getEditText()!!.text.toString()
                update_description = tv_dashboard_update_description!!.getEditText()!!.text.toString()


                Log.d("update_current_price", "" + update_stock_current_price)
                val reg_id = java.lang.String.valueOf(sessionManager!!.getId(this))
                val isupdated = databaseHelper!!.updateInformationInManagement(update_stock_id!!,
                    update_valueOfRadioDashboard,
                    update_stock_number,
                    update_stock_current_price,
                    update_stock_your_price,
                    update_stock_total_price,
                    update_description,
                    update_category_id,
                    reg_id)
                val isinvestmentupdated = databaseHelper!!.updateInformationInInvestments(
                    update_stock_total_price,
                    update_stock_total_price,
                    update_stock_your_price,
                    "",
                    update_category_id!!,
                    reg_id)

                if (isupdated == true && isinvestmentupdated == true) {
                    FancyToast.makeText(this@DashboardUpdate,
                        "Data Updated Successfully",
                        FancyToast.LENGTH_SHORT,
                        FancyToast.SUCCESS,true).show()
                    val intent = Intent(this@DashboardUpdate, HistoryListActivity::class.java)
                    intent.putExtra("update_category_id", ("" + update_category_id).toInt())
                    intent.putExtra("update_category_name", "" + update_stock_name)
                    intent.putExtra("update_stock_id", ("" + update_stock_id).toInt())
                    intent.putExtra("update_current_price", "" + update_stock_current_price)
                    Log.d("fgfhfj", "" + update_category_id)
                    startActivity(intent)
                    finish()
                } else {
                    FancyToast.makeText(this@DashboardUpdate,
                        "Data Not Updated ",
                        FancyToast.LENGTH_SHORT,
                        FancyToast.ERROR,true).show()
                }
            }
        })
        val valueOfRadioDashboard =
            (findViewById<View>(rg_dashboard_update!!.getCheckedRadioButtonId()) as RadioButton).text.toString()
        rg_dashboard_update!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.radio_buy_update) {
                radio_buy_update!!.setBackground(getDrawable(R.drawable.radio_flat_selected))
                radio_sell_update!!.setBackground(getDrawable(R.drawable.radio_flat_regular))
                radio_buy_update!!.setChecked(true)
            } else if (checkedId == R.id.radio_sell_update) {
                radio_sell_update!!.setChecked(true)
                radio_buy_update!!.setBackground(getDrawable(R.drawable.radio_flat_regular))
                radio_sell_update!!.setBackground(getDrawable(R.drawable.radio_flat_selected))
            }
        })
        et_update_dashboard_number!!.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })

        et_dashboard_update_your_price!!.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }


        })


    }
    fun result () {
        if (tv_update_total_number_stock!!.editText!!.text.toString() != "" && tv_update_dashboard_your_price!!.editText!!
                .text.toString() != ""
        ) {
            val a = tv_update_total_number_stock!!.editText!!.text.toString().toDouble()
            val b = tv_update_dashboard_your_price!!.editText!!.text.toString().toDouble()

            val result = a * b
            et_update_dashboard_total_price!!.setText(DecimalFormat("##.##").format(result))
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private fun getIncomingIntent() {
        val bundle = intent.extras
        if (bundle != null) {
            update_stock_id = bundle.getString(DatabaseHelper.MANAGEMENT_STOCK_ID)
            update_category_id = bundle.getString(DatabaseHelper.MANAGEMENT_CATEGORY_ID)
            Log.d("update_stock_id", "" + update_stock_id)
            Log.d("update_category_id", "" + update_category_id)
            if (update_stock_id != null && update_category_id != null) {
                update_valueOfRadioDashboard = bundle.getString("valueOfRadioDashboard")
                Log.d("valueOfRadioDashboard1", "" + update_valueOfRadioDashboard)
                update_stock_name = bundle.getString("stock_name")
                update_stock_number = bundle.getString("stock_number")
                update_stock_current_price = bundle.getString("stock_current_price")
                update_stock_your_price = bundle.getString("stock_your_price")
                update_stock_total_price = bundle.getString("stock_total_price")
                update_description = bundle.getString("stock_description")
                Log.d("bundle1", "" + bundle)
                if (update_valueOfRadioDashboard == "Buy") {
                    radio_buy_update!!.isChecked = true
                    radio_buy_update!!.background = getDrawable(R.drawable.radio_flat_selected)
                    radio_sell_update!!.background = getDrawable(R.drawable.radio_flat_regular)
                } else {
                    radio_sell_update!!.isChecked = true
                    radio_buy_update!!.background = getDrawable(R.drawable.radio_flat_regular)
                    radio_sell_update!!.background = getDrawable(R.drawable.radio_flat_selected)
                }
                et_dashboard_update_stock_name!!.setText(update_stock_name)
                et_update_dashboard_number!!.setText(update_stock_number)
                //et_dashboard_update_current_price.setText(update_stock_current_price);
                et_dashboard_update_your_price!!.setText(update_stock_your_price)
                et_update_dashboard_total_price!!.setText(update_stock_total_price)
                et_dashboard_update_description!!.setText(update_description)
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this@DashboardUpdate, HistoryListActivity::class.java)
        intent.putExtra("update_Category_id1", "" + update_category_id)
        Log.d("update_Category_id1", "" + update_category_id)
        startActivity(intent)

    }

}
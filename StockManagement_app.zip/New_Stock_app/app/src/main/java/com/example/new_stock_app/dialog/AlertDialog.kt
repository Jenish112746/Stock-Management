package com.example.new_stock_app.dialog

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDialogFragment
import com.example.new_stock_app.R
import com.example.new_stock_app.activity.HistoryListActivity
import com.example.new_stock_app.adapter.HistoryAdapter
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.textfield.TextInputEditText
import com.shashank.sony.fancytoastlib.FancyToast

class AlertDialog : AppCompatDialogFragment() {

    var et_dg_current_price: TextInputEditText? = null
    private var databaseHelper: DatabaseHelper? = null

    // private AlertDialogListener alertDialogListener;
    private var current_price1 = 0.0
    private var category_id = 0
    var HistoryListActivity  :HistoryListActivity? =null
    var adapter : HistoryAdapter? = null
    private val dashboardModelArrayList: ArrayList<DashboardModel> = ArrayList<DashboardModel>()
    var reg_id : Int? = null
    var sessionManager : SessionManager? = null



    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {


        val layoutInflater = requireActivity().layoutInflater
        val view: View = layoutInflater.inflate(R.layout.layout_dialog, null)
        et_dg_current_price = view.findViewById(R.id.dg_et_current_price)
        databaseHelper = DatabaseHelper(requireActivity())
        sessionManager = SessionManager(requireContext())
        reg_id = java.lang.String.valueOf(sessionManager!!.getId(requireActivity())).toInt()
        category_id = requireArguments().getInt("management_c_id")
        current_price1 = requireArguments().getDouble("management_c_price")
        val builder = AlertDialog.Builder(
            requireActivity())

        Log.e("GETTTOO",""+reg_id)

        Log.d("db_mgmt_cat_id", "" + current_price1)
        et_dg_current_price!!.setText("" + current_price1)
        builder.setView(view).setTitle("Set Your Current Price").setNegativeButton("cancel"
        ) { dialog, which -> }.setPositiveButton("Ok"
        ) { dialog, which ->

            val current_price = et_dg_current_price!!.text.toString()

            val isinserted: Boolean =
                databaseHelper!!.updateCurrentPrice(category_id, current_price,reg_id!!)
            Log.d("isinserted", "" + isinserted)

            if (isinserted) {
                val sessionManager = SessionManager(requireActivity())
                sessionManager.currentprice(requireActivity(),current_price)
                FancyToast.makeText(requireActivity(), "Successful", FancyToast.LENGTH_SHORT,FancyToast.SUCCESS,true).show()


                (activity as HistoryListActivity).getdata()
                (activity as HistoryListActivity).list()

            } else {
                FancyToast.makeText(requireActivity(),
                    "Not Successful",
                    FancyToast.LENGTH_SHORT,FancyToast.ERROR,true)
                    .show()
            }
        }
        return builder.create()
    }

}
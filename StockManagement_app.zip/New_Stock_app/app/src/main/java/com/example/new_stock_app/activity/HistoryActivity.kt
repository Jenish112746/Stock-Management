package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.shashank.sony.fancytoastlib.FancyToast
import java.text.DecimalFormat

class HistoryActivity : AppCompatActivity() {
    var history_radiogroup: RadioGroup? = null
    var rb_history_buy: RadioButton? = null
    var rb_history_sell:RadioButton? = null
    var tb_history: Toolbar? = null
    var tv_history_stock_name: TextInputLayout? = null
    var tv_history_total_number_stock:TextInputLayout? = null
    var tv_history_dashboard__current_price:TextInputLayout? = null
    var tv_history_dashboard__your_price:TextInputLayout? = null
    var tv_history_dashboard__total_price:TextInputLayout? = null
    var tv_history_dashboard_description:TextInputLayout? = null
    var et_history_dashboard_description: TextInputEditText? = null
    var et_history_dashboard_number:TextInputEditText? = null
    var et_history_stock_name:TextInputEditText? = null
    var et_history_dashboard__current_price:TextInputEditText? = null
    var et_history_dashboard__your_price:TextInputEditText? = null
    var et_history_dashboard_price:TextInputEditText? = null
    var btn_history_save: MaterialButton? = null
    var ib_back: ImageButton? = null
    var ib_delete:ImageButton? = null
    var databaseHelper: DatabaseHelper? = null
    private var valueOfStockmanage: String? = null
    private  var stock_number:kotlin.String? = null
    private  var stock_cuurent_price:kotlin.String? = null
    private  var stock_your_price:kotlin.String? = null
    private  var stock_total_price:kotlin.String? = null
    private  var stock_description:kotlin.String? = null
    private var category_iddd: Int? = null
    private var name: String? = null
    private  var current_price:kotlin.String? = null
    private var sessionManager: SessionManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        Log.e("bdgcdcvdhvcdm","++++")

        history_radiogroup = findViewById(R.id.history_radiogroup)
        rb_history_buy = findViewById(R.id.rb_history_buy)
        rb_history_sell = findViewById(R.id.rb_history_sell)
        tv_history_stock_name = findViewById(R.id.tv_history_stock_name)
        tv_history_total_number_stock = findViewById(R.id.tv_history_total_number_stock)
        tv_history_dashboard__your_price = findViewById(R.id.tv_history_dashboard__your_price)
        tv_history_dashboard__total_price = findViewById(R.id.tv_history_dashboard__total_price)
        tv_history_dashboard_description = findViewById(R.id.tv_history_dashboard_description)
        et_history_stock_name = findViewById(R.id.et_history_stock_name)
        et_history_dashboard_number = findViewById(R.id.et_history_dashboard_number)
        et_history_dashboard__your_price = findViewById(R.id.et_history_dashboard__your_price)
        et_history_dashboard_price = findViewById(R.id.et_history_dashboard_price)
        et_history_dashboard_description =
            findViewById(R.id.et_history_dashboard_history_description)
        tb_history = findViewById(R.id.toolbar_hisotry)
        btn_history_save = findViewById(R.id.btn_history_save)

        tb_history!!.title = name
        setSupportActionBar(tb_history)

        databaseHelper = DatabaseHelper(this)
        sessionManager = SessionManager(applicationContext)

        if (!sessionManager!!.checkLoggedIn(this)) {
            finish()
            return
        }
        val comingIntent = intent

        category_iddd = comingIntent.extras!!.getInt("management_category_id")
        name = comingIntent.extras!!.getString("category_name")
        current_price = comingIntent.extras!!.getString("current_price")
        Log.d("category_id", "" + category_iddd)
        Log.d("name", "" + name)
        Log.d("current_price", "" + current_price)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tb_history!!.elevation = 10f
        }
        tb_history!!.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp)
        tb_history!!.setNavigationOnClickListener {
            startActivity(Intent(this@HistoryActivity,
                LoginActivity::class.java))
        }
        et_history_stock_name!!.setText(name)

        history_radiogroup!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.rb_history_buy) {
                rb_history_buy!!.background = getDrawable(R.drawable.radio_flat_selected)
                rb_history_sell!!.background = (getDrawable(R.drawable.radio_text_design))
            } else if (checkedId == R.id.rb_history_sell) {
                rb_history_buy!!.background = (getDrawable(R.drawable.radio_text_design))
                rb_history_sell!!.background = (getDrawable(R.drawable.radio_flat_selected))
            }
        })
        btn_history_save!!.setOnClickListener(View.OnClickListener {

            Log.e("gggggggg","------>")

            if (history_radiogroup!!.checkedRadioButtonId == -1) {
                FancyToast.makeText(this@HistoryActivity,
                    "Please Select Your Value",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else if (tv_history_stock_name!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@HistoryActivity,
                    "Please Enter Stock Name ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else if (tv_history_total_number_stock!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@HistoryActivity,
                    "Please Enter Number Of Stock ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else if (tv_history_dashboard__your_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@HistoryActivity,
                    "Please Enter Stock Your Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            } else if (tv_history_dashboard__total_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@HistoryActivity,
                    "Please Enter Stock Total Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING, true).show()
            }

            val reg_id = java.lang.String.valueOf(sessionManager!!.getId(this))
            Log.e("JJJJJJJ","===>")
            Log.e("GGGGGGGG","===>"+reg_id)
            valueOfStockmanage =
                (findViewById<View>(history_radiogroup!!.checkedRadioButtonId) as RadioButton).text.toString()
            stock_number = tv_history_total_number_stock!!.getEditText()!!.text.toString()
            stock_total_price = tv_history_dashboard__total_price!!.getEditText()!!.text.toString()
            stock_your_price = tv_history_dashboard__your_price!!.getEditText()!!.text.toString()
            stock_description = tv_history_dashboard_description!!.getEditText()!!.text.toString()
            val isinserted =
                databaseHelper!!.insertManagementDataFromCategory(category_iddd.toString(),
                    valueOfStockmanage,
                    stock_number,
                    "",
                    stock_your_price,
                    stock_total_price,
                    stock_description,
                    reg_id)
            if (isinserted == true) {
                Toast.makeText(this@HistoryActivity, "Successfull", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@HistoryActivity, HistoryListActivity::class.java)
                intent.putExtra("management_category_id", category_iddd)
                intent.putExtra("current_price", DatabaseHelper.MANAGEMENT_STOCK_CURRENT_PRICE)
                intent.putExtra("category_name", name)
                startActivity(intent)
                finish()

            } else {
                Toast.makeText(this@HistoryActivity, "Not Successfull", Toast.LENGTH_SHORT).show()
            }
        })

        et_history_dashboard_number!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })
        et_history_dashboard__your_price!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })
    }
    fun result() {
        if (tv_history_total_number_stock!!.getEditText()!!.text.toString() != "" && tv_history_dashboard__your_price!!.getEditText()!!
                .text.toString() != ""
        ) {
            val a = tv_history_total_number_stock!!.getEditText()!!.text.toString().toDouble()
            val b = tv_history_dashboard__your_price!!.getEditText()!!.text.toString().toDouble()
            val result = a * b
            et_history_dashboard_price!!.setText(DecimalFormat("##.##").format(result))
        }
    }
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this@HistoryActivity, HistoryListActivity::class.java)
        val bundle = Bundle()
        bundle.putString("his_cat_id", "" + category_iddd)
        intent.putExtras(bundle)
        startActivity(intent)
        finish()
    }

}
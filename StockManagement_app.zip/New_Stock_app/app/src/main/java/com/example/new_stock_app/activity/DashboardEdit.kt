package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageButton
import androidx.appcompat.widget.Toolbar
import com.example.new_stock_app.R
import com.example.new_stock_app.databasehelper.DatabaseHelper
import com.example.new_stock_app.model.DashboardModel
import com.example.new_stock_app.sessionManager.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.shashank.sony.fancytoastlib.FancyToast
import java.text.DecimalFormat

class DashboardEdit : AppCompatActivity() {

    private var btn_dashboard_add: MaterialButton? = null
    private var tv_stock_name: TextInputLayout? = null
    private var tv_total_number_stock: TextInputLayout? = null
    private var tv_dashboard_total_price: TextInputLayout? = null
    private var et_dashboard_total_price: TextInputEditText? = null
    private var et_dashboard_number: TextInputEditText? = null
    private var et_dashboard__your_price: TextInputEditText? = null
    private var et_stock_name: TextInputEditText? = null
    private var et_dashboard_description: TextInputEditText? = null
    private var tv_dashboard_your_price: TextInputLayout? = null
    private var tv_dashboard__description: TextInputLayout? = null
    private var rg_dashboard: RadioGroup? = null
    private var radio_buy: RadioButton? = null
    private var radio_sell: RadioButton? = null
    private var valueOfRadioDashboard: kotlin.String? = null
    private var stock_name: kotlin.String? = null
    private var stock_number: kotlin.String? = null
    private var stock_your_price: kotlin.String? = null
    private var stock_total_price: kotlin.String? = null
    private var stock_description: kotlin.String? = null
    private var databaseHelper: DatabaseHelper? = null
    private var dashboardModel: DashboardModel? = null
    private var toolbar_dashboard_edit: Toolbar? = null
    private var sessionManager: SessionManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_edit)
        databaseHelper = DatabaseHelper(this)
        dashboardModel = DashboardModel()

        tv_stock_name = findViewById(R.id.tv_stock_name)
        tv_total_number_stock = findViewById(R.id.tv_total_number_stock)
        tv_dashboard_total_price = findViewById(R.id.tv_dashboard__total_price)
        tv_dashboard_your_price = findViewById(R.id.tv_dashboard__your_price)
        tv_dashboard__description = findViewById(R.id.tv_dashboard__description)
        btn_dashboard_add = findViewById(R.id.btn_dashboard_add)
        toolbar_dashboard_edit = findViewById(R.id.toolbar_dashboard_edit)
        et_stock_name = findViewById(R.id.et_stock_name)
        et_dashboard_total_price = findViewById(R.id.et_dashboard_price)
        et_dashboard__your_price = findViewById(R.id.et_dashboard__your_price)
        et_dashboard_number = findViewById(R.id.et_dashboard_number)
        et_dashboard_description = findViewById(R.id.et_dashboard_description)
        rg_dashboard = findViewById(R.id.radiogroup_dashboard)
        radio_buy = findViewById(R.id.radio_buy)
        radio_sell = findViewById(R.id.radio_sell)

        setSupportActionBar(toolbar_dashboard_edit)
        toolbar_dashboard_edit!!.setTitle("Demo")
        toolbar_dashboard_edit!!.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp)

        toolbar_dashboard_edit!!.setNavigationOnClickListener {
            startActivity(Intent(this@DashboardEdit, DashBoard::class.java))
            finish()
        }
        result()

        sessionManager = SessionManager(applicationContext)
        if (!sessionManager!!.checkLoggedIn(this)) {
            finish()
            return
        }


        btn_dashboard_add!!.setOnClickListener(View.OnClickListener {

            if (rg_dashboard!!.getCheckedRadioButtonId() == -1) {
                FancyToast.makeText(this@DashboardEdit,
                    "Please Select Your Condition ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_stock_name!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardEdit,
                    "Please Enter Stock Name ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_total_number_stock!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardEdit,
                    "Please Enter Number Of Stock ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            }
            else if (tv_dashboard_your_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardEdit,
                    "Please Enter Stock Your Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            } else if (tv_dashboard_total_price!!.getEditText()!!.text.toString() == "") {
                FancyToast.makeText(this@DashboardEdit,
                    "Please Enter Stock Total Price ",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.WARNING,true).show()
            }
            else {
                valueOfRadioDashboard =
                    (findViewById<View>(rg_dashboard!!.getCheckedRadioButtonId()) as RadioButton).text.toString()
                stock_name = tv_stock_name!!.editText!!.text.toString()
                stock_number = tv_total_number_stock!!.getEditText()!!.text.toString()
                stock_your_price = tv_dashboard_your_price!!.getEditText()!!.text.toString()
                stock_total_price = tv_dashboard_total_price!!.getEditText()!!.text.toString()
                stock_description = tv_dashboard__description!!.getEditText()!!.text.toString()


                val reg_id = sessionManager!!.getId(this)
                val isInserted3 = databaseHelper!!.insertCategory(stock_name, reg_id.toString())
                val category_id = databaseHelper!!.getUserID(stock_name!!)
                val manage_cat_id = databaseHelper!!.getManagementId(category_id!!.toInt())
                Log.d("result20", "" + category_id)
                Log.d("result200", "" + manage_cat_id)
                Log.d("result2000", "" + reg_id)
                val isInserted2 = databaseHelper!!.insertManagementDataFromCategory(category_id,
                    valueOfRadioDashboard,
                    stock_number,
                    stock_your_price,
                    stock_your_price,
                    stock_total_price,
                    stock_description,
                    reg_id.toString())
                val isInserted4 = databaseHelper!!.insertInvestments(stock_total_price,
                    stock_total_price,
                    stock_your_price,
                    "",
                    category_id,
                    reg_id.toString())

                if (isInserted3 == true && isInserted2 == true && isInserted4 == true) {
                    Log.d("category", "" + isInserted3)
                    Log.d("management", "" + isInserted2)
                    Log.d("investments", "" + isInserted2)


                    sessionManager!!.currentprice(this,stock_your_price)

                    startActivity(Intent(this@DashboardEdit, DashBoard::class.java))
                    finish()
                } else {
                    Toast.makeText(this@DashboardEdit, "Record Not Added", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        })
        radio_buy!!.isChecked = true
        radio_buy!!.background = getDrawable(R.drawable.radio_flat_selected)
        radio_sell!!.background = getDrawable(R.drawable.radio_flat_regular)

        val valueOfRadioDashboard =
            (findViewById<View>(rg_dashboard!!.getCheckedRadioButtonId()) as RadioButton).text.toString()
        rg_dashboard!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.radio_buy) {
                radio_buy!!.isChecked = true
                radio_buy!!.background = getDrawable(R.drawable.radio_flat_selected)
                radio_sell!!.background = getDrawable(R.drawable.radio_flat_regular)
            } else if (checkedId == R.id.radio_sell) {
                radio_sell!!.isChecked = true
                radio_buy!!.background = getDrawable(R.drawable.radio_flat_regular)
                radio_sell!!.background = getDrawable(R.drawable.radio_flat_selected)
            }
        })


        et_dashboard_number!!.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })

        et_dashboard__your_price!!.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                result()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })

    }
    fun result() {
        if (tv_total_number_stock!!.editText!!.text.toString() != "" && tv_dashboard_your_price!!.editText!!
                .text.toString() != ""
        ) {
            val a = tv_total_number_stock!!.editText!!.text.toString().toDouble()
            val b = tv_dashboard_your_price!!.editText!!.text.toString().toDouble()
            val result = a * b
            et_dashboard_total_price!!.setText(DecimalFormat("##.##").format(result))
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this@DashboardEdit, DashBoard::class.java))
        finish()
    }
}
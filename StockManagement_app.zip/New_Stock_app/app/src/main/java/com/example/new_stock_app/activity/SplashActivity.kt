package com.example.new_stock_app.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.new_stock_app.R
import com.example.new_stock_app.sessionManager.SessionManager

class SplashActivity : AppCompatActivity() {
    var sessionManager: SessionManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_splash)
        sessionManager = SessionManager(applicationContext)

        Handler().postDelayed(Runnable {
            if (sessionManager!!.checkLoggedIn(this)) {
                startActivity(Intent(this@SplashActivity, DashBoard::class.java))
                finish()
                return@Runnable
            } else {
                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                finish()
                return@Runnable
            }
        }, 3000)
    }
}